package com.example.useractionevent

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class UserActionEventApplicationTests {

    @Test
    fun contextLoads() {
    }

}
